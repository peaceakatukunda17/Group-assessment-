%% Bisection mtd
%while loop

f = @(x) x^3-4*x-9;
a = 2;
b = 3;
tol = 1e-4;
maxiter = 100;
iter = 0;
if f(a)*f(b) >= 0
    error ( 'invalid interval[a,b]')
end
fprintf('while loop: \niter\tc\t\tg(c)\n')
c = (a+b)/2;
fc = f(c);
while (abs(fc)>= tol) && ((b-a)/2 >= tol) && (iter < maxiter)
    iter = iter + 1;
    fprintf('%d\t%.6f\t%.6f\n', iter, c , fc)
    if f(a)*fc < 0
        b = c;
    else
        a = c; 
    end
    c = (a+b)/2;
    fc = f(c);
end
fprintf('\nroot = %.6f after %d iters\n', c , iter)

% for loop
f =  @(x) x^3 - 4*x - 9;
a = 2;
b = 3;
tol = 1e-4;
maxiter = 20;
if f(a)*f(b) >= 0
    error('invalid interval [a, b]')
end
fprintf('For loop \niter\tc\t\tf(c)\n')
for iter = 1:maxiter
    c = (a+b)/2;
    fc = f(c);
fprintf('%d\t%.6f\t%.6\n', iter, c , fc)

if abs(fc)< tol || (b-a)/2< tol
    fprintf('\nroot = %.6f at iter %d\n', c, iter)
    break
end
if f(a)*fc < 0
    b = c;
else
    a = c; 
end
end

%% NRM
% while loop
f = @(x) x^3 - 4*x - 9;
df = @(x) 3*x^2 - 4;
x0 = 2.5;
iter = 0;
tol = 1e-6;
maxiter = 100;
dx1 = inf;
fprintf('while loop NRM: \niter\tx0\t\tx1\t\tf(x1)\n')
while (abs(f(x0)) >= tol) && (iter < maxiter)
    iter = iter + 1;
    if abs(df(x0)) < 1e-12
        error('f''=0')
    end
    x1 = x0-f(x0)/df(x0);
    dx2 = abs(x1-x0);
    fprintf ('%d\t%.6f\t%.6f\t%.6\n', iter, x0, x1, f(x1))
    x0 = x1;
end
fprintf('\nroot = %.6f after %d iters\n', x0, iter)
%  for loop
f = @(x) x^3 - 4*x - 9;
df = @(x) 3*x^2 - 4;
x0 = 2.5;
tol = 1e-4;
maxiter = 10;
fprintf('for loop NRM: \niter\tx0\t\tx1\t\tf(x1)\n')
for iter = 1:maxiter
    if abs(df(x0)) < 1e-12
        error('f''=0, division by zero')

    end
     x1 = x0-f(x0)/df(x0);
      fprintf ('%d\t%.6f\t%.6f\t%.6\n', iter, x0, x1, f(x1))
      if abs(f(x1)) < tol || abs(x1-x0) < tol
          fprintf('\nroot = %.6f at iter %d iters\n', x1, iter)
          break
      end
          x0 = x1;
end

%% secant method
% while loop
f = @(x) x^3 - 4*x - 9;
x0 = 2;
x1 = 3;
tol = 1e-4;
maxiter = 100;
iter = 0;
dx = inf;
fprintf('while loop SECANT : \niter\tx0\t\tx1\t\tf(x2)\n')
while (abs(f(x1)) >= tol) && (dx >= tol) && (iter < maxiter)
    iter = iter + 1;
    if abs(f(x1)-f(x0)) < 1e-12
        error('div by zero')
    end
    x2 = x1-f(x1)*(x1-x0)/(f(x1)-f(x0));
    dx = abs(x2-x1);
    fprintf ('%d\t%.6f\t%.6f\t%.6f\t%.6\n', iter, x0, x1,x2, f(x2))
    x0 = x1;
    x1 = x2;
end
fprintf('\nroot = %.6f after %d iters\n', x1, iter)

% for loop
f = @(x) x^3 - 4*x - 9;
x0 = 2;
x1 = 3;
tol = 1e-4;
maxiter = 10;
fprintf('for loop SECANT: \niter\tx0\t\tx1\t\tf(x2)\n')
for iter = 1:maxiter
    if abs(f(x1)-f(x0)) < 1e-12
        error('div by zero')
    end
    x2 = x1-f(x1)*(x1-x0)/(f(x1)-f(x0));
    fprintf('%d\t%.6f\t%.6f\t%.6f\t%.6f\n',iter, x0, x1,x2, f(x2));

      if abs(f(x2)) < tol || abs(x2-x1) < tol
          fprintf('\nroot = %.6f at iter %d\n', x2, iter)
          break
      end
          x0 = x1;
          x1 = x2;
end
%% fixed point iteration
%while loop
g = @(x) (4*x + 9)^(1/3);
f = @(x) x^3 -4*x -9;
x0 = 2.5;
tol = 1e-4;
maxiter = 100;
iter = 0;
dx = inf;
x1 = x0;
fprintf('while loop FIXED POINT ITERATION: \niter\tx0\t\tx1\t\tf(x1)\n')
while (abs(f(x0)) >= tol) && (dx >= tol) && (iter < maxiter)
    iter = iter + 1;
    X1 = g(x0);
    dx = abs(x1 - x0);
      fprintf ('%d\t%.6f\t%.6f\t%.6\n', iter, x0, x1, f(x1))
      x0 = x1;
end
fprintf('\nroot = %.6f after %d inters\n', x0, iter)
% for loop
g = @(x) (4*x + 9)^(1/3);
f = @(x) x^3 -4*x -9;
x0 = 2.5;
tol = 1e-4;
maxiter = 20;
fprintf('for loop FIXED POINT ITERATION: \niter\tx0\t\tx1\t\tf(x1)\n')
for iter = 1:maxiter
    x1 =g(x0);
     fprintf ('%d\t%.6f\t%.6f\t%.6\n', iter, x0, x1, f(x1))
     if abs(x1- x0)< tol || abs(f(x1)) < tol
         fprintf('\nroot = %.6f at iter %d\n', x1, iter)
         break
     end
     x0 = x1;
end

%%% euler method
%while loop
f = @(x,y) 0.8*x + 1.2*y ;
x0 = 0;
y0 = 0.5;
h = 0.25;
x_end = 1;
x = x0;
y = y0;
iter = 0;
fprintf('EULER: \niter\tx\t\ty\t\tf(x,y)\n')
fprintf('%d\t%.2f\t%.6f\t%.6f\n',iter,x, y, f(x,y))
while x < x_end - 1e-9
    iter = iter + 1;
    y_new = y + h*f(x,y);
    x = x+ h;
    y = y_new;
    fprintf('%d\t%.2f\t%.6f\t%.6f\n',iter, x, y, f(x,y))
end
fprintf('\nfinal y(1) = %.6f after %d steps\n', y, iter)

%for loop
f = @(x,y) 0.8*x + 1.2*y; 
x0 = 0;
y0 = 0.5;
h = 0.25;
x_end = 1;
n = (x_end-x0)/h;
x = x0; 
y = y0;
fprintf('EULER: \niter\tx\t\ty\t\tf(x_n,y_n)\n')
fprintf('0\t%.2f\t%.6f\t%.6f\n',x, y, f(x,y))
for i = 1:n
    slope = f(x,y);
    y_new = y+h*slope;
    x_new = x+h;
    x= x_new;
    y = y_new;
    fprintf('%d\t%.2f\t%.6f\t%.6f\n',i, x, y, f(x,y))
end
fprintf('\nfinal y(1)=%.6f\n', y)
%% fourth order runge kutta 
%while loop
f = @(x,y) 0.8*x + 1.2*y; 
x0 = 0;
y0 = 0.5;
h = 0.25;
x_end = 1;
x = x0; 
y = y0;
iter = 0;
fprintf('RK4: \niter\tx\t\ty\t\tf(x,y)\n')
fprintf('%d\t%.2f\t%.6f\t%.6f\n',x, y, f(x,y))
while x < x_end - 1e-9
    iter = iter + 1;
    k1 = f(x,y);
    k2 = f(x+h/2, y+h*k1/2);
    k3 = f(x+h/2, y+h*k2/2);
    k4 = f(x+h, y + h*k3);
    y_new = y+h*(k1 + 2*k2 + 2*k3 + k4)/6;
    x = x+h;
    y = y_new;
    fprintf('%d\t%.2f\t%.6f\t%.6f\n',iter, x, y, f(x,y))
end
fprintf('\nfinal RK4 y(1)=%.6f after %d steps\n',y ,iter)
% for loop
f = @(x,y) 0.8*x + 1.2*y; 
x0 = 0;
y0 = 0.5;
h = 0.25;
x_end = 1;
n = (x_end-x0)/h;
x = x0; 
y = y0;
fprintf('EULER: \niter\tx\t\ty\t\tf(x,y)\n')
fprintf('0\t%.2f\t%.6f\t%.6f\n',x, y, f(x,y))
for i = 1:n
     k1 = f(x,y);
    k2 = f(x+h/2, y+h*k1/2);
    k3 = f(x+h/2, y+h*k2/2);
    k4 = f(x+h, y + h*k3);
    y_new = y+h*(k1 + 2*k2 + 2*k3 + k4)/6;
    x_new = x+h;
    x = x_new;
    y = y_new;
    fprintf('%d\t%.2f\t%.6f\t%.6f\n',i, x, y, f(x,y))
end
fprintf('\nfinal RK4 y(1)=%.6f\n',y)











         
          




